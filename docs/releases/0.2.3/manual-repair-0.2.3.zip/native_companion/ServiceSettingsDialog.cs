using System;
using System.Drawing;
using System.Windows.Forms;
using System.Threading.Tasks;

// Connection checks send fixed test text only, never game data or chat history.
sealed class ServiceSettingsDialog : Form {
    public ServiceConfig SavedConfig {get;private set;}
    public ServiceSettingsDialog(string configPath,ServiceConfig current,string python,string root) {
        if(current==null)throw new ArgumentNullException("current");
        Text="AI 互动设置"; ClientSize=new Size(500,482);
        StartPosition=FormStartPosition.CenterParent;
        Font=new Font("Microsoft YaHei UI",10); AutoScaleMode=AutoScaleMode.Dpi;
        FormBorderStyle=FormBorderStyle.FixedDialog; MaximizeBox=false; MinimizeBox=false;
        var names=new[]{"DeepSeek", "Kimi", "通义千问", "MiniMax", "其他兼容服务（高级）", "本机模型（高级）"};
        var urls=new[]{"https://api.deepseek.com", "https://api.moonshot.cn/v1", "https://dashscope.aliyuncs.com/compatible-mode/v1", "https://api.minimax.cn/v1"};
        var models=new[]{"deepseek-flash", "kimi-k2.6", "qwen-plus", "MiniMax-M3"};
        var panel=new TableLayoutPanel {Dock=DockStyle.Fill,Padding=new Padding(18),ColumnCount=1,RowCount=8};
        foreach(int height in new[]{26,36,24,26,36,132,122,44})panel.RowStyles.Add(new RowStyle(SizeType.Absolute,height));
        panel.Controls.Add(new Label {Text="AI 服务商",AutoSize=true});
        var provider=new ComboBox {DropDownStyle=ComboBoxStyle.DropDownList,Dock=DockStyle.Fill};
        provider.Items.AddRange(names);panel.Controls.Add(provider);
        panel.Controls.Add(new Label {Text="推荐使用 DeepSeek",AutoSize=true,ForeColor=Color.DimGray,Font=new Font(Font.FontFamily,9)});
        panel.Controls.Add(new Label {Text="API 密钥",AutoSize=true});
        var key=new TextBox {Text=current.api_key,UseSystemPasswordChar=true,Dock=DockStyle.Fill};panel.Controls.Add(key);
        var advanced=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=1,RowCount=4,Margin=new Padding(0)};
        foreach(int height in new[]{26,36,26,36})advanced.RowStyles.Add(new RowStyle(SizeType.Absolute,height));
        var endpoint=new TextBox {Text=current.base_url,Dock=DockStyle.Fill};
        var model=new TextBox {Text=current.model,Dock=DockStyle.Fill};
        advanced.Controls.Add(new Label {Text="接口基础地址（本机可用 HTTP，其他用 HTTPS）",AutoSize=true});advanced.Controls.Add(endpoint);
        advanced.Controls.Add(new Label {Text="模型名称",AutoSize=true});advanced.Controls.Add(model);panel.Controls.Add(advanced);
        var connection=new Label {Dock=DockStyle.Fill};panel.Controls.Add(connection);
        var actions=new FlowLayoutPanel {Dock=DockStyle.Fill,FlowDirection=FlowDirection.RightToLeft};
        var save=new Button {Text="保存",AutoSize=true};
        var cancel=new Button {Text="取消",AutoSize=true,DialogResult=DialogResult.Cancel};
        actions.Controls.Add(save);actions.Controls.Add(cancel);panel.Controls.Add(actions);Controls.Add(panel);
        // Keep hidden advanced controls in their assigned row; automatic placement
        // otherwise moves the status label into the collapsed row.
        for(int row=0;row<panel.Controls.Count;row++)
            panel.SetCellPosition(panel.Controls[row],new TableLayoutPanelCellPosition(0,row));
        AcceptButton=save; CancelButton=cancel;
        Action refresh=()=>{
            bool custom=provider.SelectedIndex>=4;
            advanced.Visible=custom;panel.RowStyles[5].Height=custom?132:0;
            ClientSize=new Size(500,custom?482:350);
            connection.ForeColor=Color.DimGray;
            connection.Text=(custom?"填写兼容接口与模型；本机端口以实际服务为准。": "接口和模型已自动配置。")+
                "\n密钥加密保存；云端留空使用原版，本机可免密钥。\n保存自动验证，只发送固定测试文字。";
        };
        int selected=ServiceConfig.IsLocalEndpoint(current.base_url)?5:4;
        for(int i=0;i<urls.Length;i++)if(String.Equals((current.base_url??"").TrimEnd('/'),urls[i],StringComparison.OrdinalIgnoreCase)&&current.model==models[i])selected=i;
        provider.SelectedIndex=selected;refresh();
        provider.SelectedIndexChanged+=(s,e)=>{
            key.Clear();
            if(provider.SelectedIndex<4){endpoint.Text=urls[provider.SelectedIndex];model.Text=models[provider.SelectedIndex];}
            if(provider.SelectedIndex==5){endpoint.Text="http://127.0.0.1:1234/v1";model.Text="";}
            refresh();
        };
        // A destination edit must not carry a previously entered key to another host.
        endpoint.TextChanged+=(s,e)=>{key.Clear();};
        Func<ServiceConfig> read=()=>new ServiceConfig {enabled=!String.IsNullOrWhiteSpace(key.Text)||ServiceConfig.IsLocalEndpoint(endpoint.Text.Trim()),base_url=endpoint.Text.Trim().TrimEnd('/'),model=model.Text.Trim(),api_key=key.Text.Trim()};
        Func<bool> valid=()=>{
            if((read().enabled || provider.SelectedIndex==5) && (!ServiceConfig.IsValidEndpoint(endpoint.Text.Trim()) || String.IsNullOrWhiteSpace(model.Text))) {
                connection.Text="请填写有效接口和模型；HTTP 仅支持 localhost、127.0.0.1 或 [::1]。";return false;
            }
            return true;
        };
        ServiceConfig verified=null;
        Func<ServiceConfig,Task<bool>> check=async config=>{
            if(!config.enabled){connection.Text="原版模式，不调用 API。";return true;}
            if(verified!=null&&verified.base_url==config.base_url&&verified.model==config.model&&verified.api_key==config.api_key)return true;
            save.Enabled=key.Enabled=provider.Enabled=endpoint.Enabled=model.Enabled=false;
            connection.ForeColor=Color.DimGray;connection.Text="正在连接 API，请稍候……";
            string error=await Task.Run(()=>ServiceConnectionCheck.Check(python,root,config));
            if(IsDisposed)return false;
            save.Enabled=key.Enabled=provider.Enabled=endpoint.Enabled=model.Enabled=true;
            connection.ForeColor=error==""?Color.DarkGreen:Color.Firebrick;
            connection.Text=error==""?"连接成功：API 已返回文字，可以保存并启动 AI 互动。":ServiceConnectionCheck.Describe(error)+"\n未启动 AI；请检查密钥后重新保存，或清空密钥使用原版。";
            if(error=="")verified=config;
            return error=="";
        };
        save.Click+=async(s,e)=>{
            if(!valid())return;
            var next=read();
            if(!await check(next)||IsDisposed)return;
            try {ServiceConfigStore.Save(configPath,next);SavedConfig=next;DialogResult=DialogResult.OK;}
            catch {MessageBox.Show(this,"配置保存失败，原设置保留。");}
        };
    }
}
