using System;
using System.Diagnostics;
using System.IO;
using System.Security.Cryptography;

// Each isolated runtime has an exact executable/resource pair. The playable
// profile additionally requires the bounded restore observer; no original patch.
static class InsetRuntime {
    internal static string Verify(string root,bool timed=false,bool scoped=false,bool playable=false) {
        if(playable)scoped=true;
        if(timed && scoped)throw new ArgumentException("Only one runtime profile is allowed.");
        string folder=Path.GetFullPath(Path.Combine(root,"work",playable?"in-game-scoped-load-boundary-prototype":scoped?"in-game-entry-scoped-prototype":timed?"in-game-timed-wait-prototype":"in-game-inset-prototype","runtime","exec"));
        string name=playable?"eva-scoped-load-boundary.exe":scoped?"eva-entry-scoped.exe":timed?"eva-timed-wait.exe":"eva-inset.exe";
        VerifyFile(Path.Combine(folder,name),playable?"67F57C9C5E768169254D14A5E68D5C7DFA954E325FBD6F0C6AE0E6B4EDBC5188":scoped?"222CC1778D96CF39DBEF665D8032B3C27F9347A3BFB1C2FB1F9EDD907D8930CD":timed?"7C81F2A3969F956ED9F6D75F06F8BF5FB9D60699B2B63C8A4DE0EE29085B8B12":"96890012A22044831434F87FC2663730606454EBEB4C858E252AFEB6DFCB4849");
        VerifyFile(Path.Combine(folder,"..","exec.idx"),playable?"69C586E8EC27E14F1EC7268B36D9154D8F34C899D124694891685D05137043EE":scoped?"6B4A93FC4AC5802C75FA77FF130197B18095EF3427AE84F263042E5E8D975DF3":"218723CB25CA0A9AD10D7FE99EFFDC340D82A8185FBBA5359E56625DA9DFBDA4");
        VerifyFile(Path.Combine(folder,"..","exec.lb5"),playable?"5940E6D849F358BCBC59A906534AB63603B5BEB014F20D59534CE5BE1254BFCC":scoped?"FF715B95B5DC9BC416D599DF9622700DCA6225847D4A9B53BFBECB8981D7BFF4":"2B03A0ACE1A308C7E999C664B5B7CFD7B26A752A0E78C74CC7750C3827673837");
        foreach(string path in new[]{Path.Combine(folder,name+".manifest"),
            Path.Combine(root,"work","NativeSaveObserverProbe.exe"),Path.Combine(root,"work","NativeReplyChannel.exe"),
            Path.Combine(root,"native_companion","native_exchange_host.py")})
            if(!File.Exists(path))throw new InvalidOperationException("游戏内 AI 组件不完整，请修复安装。");
        if(playable && !File.Exists(Path.Combine(root,"work","NativeLoadMonitor.exe")))throw new InvalidOperationException("读档记忆组件缺失。");
        return Path.Combine(folder,name);
    }
    static void VerifyFile(string path,string expected) {
        using(var hash=SHA256.Create())using(var file=File.OpenRead(path))
            if(BitConverter.ToString(hash.ComputeHash(file)).Replace("-","")!=expected)
                throw new InvalidOperationException("游戏内 AI 程序或素材版本不匹配，请修复安装。");
    }
    public static Process Start(string root,bool timed=false,bool scoped=false,bool playable=false) {
        string executable=Verify(root,timed,scoped,playable);
        // Do not silently attach a fresh memory controller to an existing game.
        // It may already have a controller or be on an unobserved save timeline.
        foreach(string name in new[]{"eva","eva-input-compat","eva-inset","eva-load-boundary","eva-bounded-wait","eva-timed-wait","eva-entry-gate","eva-entry-scoped","eva-scoped-load-boundary"}) {
            foreach(var process in Process.GetProcessesByName(name)) {
                using(process) {
                    if(!process.HasExited)throw new InvalidOperationException("请先正常退出正在运行的游戏，再启动 AI 版。");
                }
            }
        }
        return PortableRuntime.Start(executable);
    }
}

