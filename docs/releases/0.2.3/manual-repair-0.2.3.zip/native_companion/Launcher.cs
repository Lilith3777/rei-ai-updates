using System;
using System.Drawing;
using System.IO;
using System.Diagnostics;
using System.Windows.Forms;

class Launcher : Form {
    readonly string root,python;
    Process aiGame;
    NativeExchangeHostClient host;
    readonly NotifyIcon notice=new NotifyIcon {Icon=SystemIcons.Information,Text="绫波育成计划 AI",Visible=true};
    string reportedError="";
    readonly Timer monitor=new Timer {Interval=500};
    readonly Label status=new Label {Bounds=new Rectangle(24,297,412,30),TextAlign=ContentAlignment.MiddleCenter,ForeColor=Color.FromArgb(171,186,205)};
    public Launcher(string project,string interpreter){
        root=project;python=interpreter;
        Text="绫波育成计划 · 启动器";ClientSize=new Size(460,360);AutoScaleMode=AutoScaleMode.Dpi;
        StartPosition=FormStartPosition.CenterScreen;FormBorderStyle=FormBorderStyle.FixedSingle;MaximizeBox=false;
        Font=new Font("Microsoft YaHei UI",11);BackColor=Color.FromArgb(22,30,48);ForeColor=Color.White;
        var title=new Label {Text="绫波育成计划",AutoSize=false,TextAlign=ContentAlignment.MiddleCenter,Bounds=new Rectangle(24,22,412,42),Font=new Font(Font.FontFamily,20,FontStyle.Bold)};
        var original=MakeButton("启动原版游戏",88);var ai=MakeButton("启动AI重置版",165);
        original.Click+=(s,e)=>Start(false);ai.Click+=(s,e)=>Start(true);
        Controls.Add(title);Controls.Add(original);Controls.Add(ai);Controls.Add(status);
        Controls.Add(new Label {Text="当前版本："+ReadInstalledVersion(root),Bounds=new Rectangle(24,332,412,20),
            TextAlign=ContentAlignment.MiddleCenter,Font=new Font(Font.FontFamily,9),ForeColor=Color.FromArgb(145,164,189)});
        var contact=new Button {Text="联系作者",Bounds=new Rectangle(40,250,120,38),
            FlatStyle=FlatStyle.Flat,BackColor=BackColor,ForeColor=Color.FromArgb(168,213,231),Cursor=Cursors.Hand};
        contact.FlatAppearance.BorderColor=Color.FromArgb(72,98,120);
        contact.FlatAppearance.MouseOverBackColor=Color.FromArgb(35,49,68);
        contact.Click+=(s,e)=>{using(var dialog=new ContactDialog())dialog.ShowDialog(this);};
        Controls.Add(contact);
        var settings=new Button {Text="设置",Bounds=new Rectangle(170,250,120,38),FlatStyle=FlatStyle.Flat,
            BackColor=BackColor,ForeColor=Color.FromArgb(168,213,231),Cursor=Cursors.Hand};
        settings.FlatAppearance.BorderColor=Color.FromArgb(72,98,120);
        settings.Click+=(s,e)=>{try{using(var dialog=new AudioSettingsDialog(root))dialog.ShowDialog(this);}catch(Exception ex){MessageBox.Show(this,ex.Message,"声音设置");}};
        Controls.Add(settings);
        var update=new Button {Text="更新",Bounds=new Rectangle(300,250,120,38),FlatStyle=FlatStyle.Flat,
            BackColor=BackColor,ForeColor=Color.FromArgb(168,213,231),Cursor=Cursors.Hand};
        update.FlatAppearance.BorderColor=Color.FromArgb(72,98,120);
        update.Click+=(s,e)=>{using(var dialog=new UpdateDialog(root,python)){dialog.ShowDialog(this);if(dialog.Installed)Close();}};
        Controls.Add(update);
        notice.BalloonTipClicked+=(s,e)=>{Show();Activate();Start(true);};
        notice.DoubleClick+=(s,e)=>{Show();Activate();};
        monitor.Tick+=(s,e)=>{
            if(aiGame==null)return;
            if(host!=null && host.ServiceError=="")reportedError="";
            if(!GameRunning()){ReleaseSession();status.Text="游戏已退出。";Show();}
            else if(host!=null && host.Status=="closed")status.Text="AI 服务已停止，等待中的交谈会自动回退。";
            else if(host!=null && host.ServiceError!=""){
                status.Text=host.Enabled?"AI 输入已恢复，可重新交谈。":"AI 连接失败，点「启动AI重置版」重新设置。";
                if(reportedError!=host.ServiceError){reportedError=host.ServiceError;notice.ShowBalloonTip(10000,"AI 未能回复，已回退原版",ServiceConnectionCheck.Describe(reportedError)+" 点击此通知可重新设置连接。",ToolTipIcon.Warning);}
            }
            else if(host!=null && !host.Enabled)status.Text="AI 已关闭，交谈使用原版。";
            else if(host!=null && !host.MemoryReady)status.Text="等待开始游戏或读取存档，以连接 AI 记忆。";
            else if(host!=null)status.Text="AI 已就绪，请在游戏内点击「交谈」。";
        };
        monitor.Start();
        FormClosing+=(s,e)=>{if(GameRunning()){e.Cancel=true;Hide();}};
    }
    internal static string ReadInstalledVersion(string project){
        try{
            var serializer=new System.Web.Script.Serialization.JavaScriptSerializer();
            Version latest=null;
            Action<object> include=value=>{
                string text=value as string;Version parsed;
                if(text==null || !System.Text.RegularExpressions.Regex.IsMatch(text,@"\A(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\z") || !Version.TryParse(text,out parsed))
                    throw new FormatException();
                if(latest==null || parsed.CompareTo(latest)>0)latest=parsed;
            };
            string path=Path.Combine(project,"version.json");
            if(File.Exists(path))include(serializer.Deserialize<System.Collections.Generic.Dictionary<string,object>>(File.ReadAllText(path))["version"]);
            string backups=Path.Combine(project,"patch-backups");
            if(Directory.Exists(backups))foreach(string directory in Directory.GetDirectories(backups,"patch-*")){
                string journal=Path.Combine(directory,"transaction.json");
                if(!File.Exists(journal))continue;
                var record=serializer.Deserialize<System.Collections.Generic.Dictionary<string,object>>(File.ReadAllText(journal));
                object state;if(record.TryGetValue("state",out state) && Convert.ToString(state)=="installed")
                    include(((System.Collections.Generic.Dictionary<string,object>)record["manifest"])["version"]);
            }
            return latest==null?"未标注":latest.ToString(3);
        }catch{return "版本信息不可用";} // Display failure must not prevent playing.
    }
    Button MakeButton(string text,int y){
        var button=new Button {Text=text,Bounds=new Rectangle(40,y,380,58),FlatStyle=FlatStyle.Flat,BackColor=Color.FromArgb(47,65,95),ForeColor=Color.White,Cursor=Cursors.Hand};
        button.FlatAppearance.BorderColor=Color.FromArgb(107,143,188);return button;
    }
    void Start(bool useAI){
        try{
            if(GameRunning()){
                if(useAI){
                    string settings=Path.Combine(root,"native_companion","data","service.dat");
                    using(var dialog=new ServiceSettingsDialog(settings,ServiceConfigStore.Load(settings),python,root)){
                        if(dialog.ShowDialog(this)!=DialogResult.OK)return;
                        if(host==null||host.Status=="closed")throw new InvalidOperationException("AI 后台已退出，请正常退出游戏后重新启动 AI 版。");
                        if(!host.Configure(dialog.SavedConfig,retry:true))throw new InvalidOperationException("当前交谈还未结束，请返回房间后重新连接。");
                        reportedError="";
                    }
                    OriginalRuntime.Activate(aiGame);
                }
                else MessageBox.Show(this,"请先正常退出 AI 版，再启动原版游戏。");
                return;
            }
            ReleaseSession();
            // Recover an interrupted patch before loading any updated game code.
            if(Directory.Exists(Path.Combine(root,"patch-backups"))){
                UpdateDialog.EnsureStopped();
                UpdateDialog.Invoke(root,python,new {action="recover"});
            }
            if(useAI){
                string path=Path.Combine(root,"native_companion","data","service.dat");
                ServiceConfig config;
                try{config=ServiceConfigStore.Load(path);}
                catch{MessageBox.Show(this,"API 设置无法读取，原文件已保留。将启动原版游戏。");StartOriginal();return;}
                using(var dialog=new ServiceSettingsDialog(path,config,python,root)){
                    if(dialog.ShowDialog(this)!=DialogResult.OK)return;
                    config=dialog.SavedConfig;
                }
                if(!config.CanConnect() || !File.Exists(python)){StartOriginal();return;}
                AudioSettings.Prepare(root,Path.Combine(root,"work","in-game-scoped-load-boundary-prototype","runtime","exec"));
                aiGame=InsetRuntime.Start(root,playable:true);
                if(!aiGame.WaitForInputIdle(10000) || aiGame.HasExited)throw new InvalidOperationException("游戏启动未就绪。");
                host=new NativeExchangeHostClient(python,root,aiGame.Id,Path.Combine(root,"native_companion","data","native-memory.sqlite3"),playable:true);
                if(!host.Configure(config))throw new InvalidOperationException("AI 设置未被服务接受。");
                status.Text="请在游戏内点击「交谈」。";
                OriginalRuntime.Activate(aiGame);
            }else{
                StartOriginal();
            }
        }catch(Exception error){
            string stage=host==null?"":host.FailureStage;
            if(host!=null){host.Dispose();host=null;}
            status.Text=GameRunning()?"AI 未连接，等待中的交谈会自动回退。":"启动未完成。";
            string detail=stage=="initial_observation"?"游戏初始状态读取失败。":
                stage=="journal_open"?"AI 记忆文件无法打开。":stage=="runtime_open"?"AI 记忆服务初始化失败。":
                stage=="channel_open"?"游戏内对话通道未就绪。":stage=="serving"?"AI 对话服务已退出。":error.Message;
            MessageBox.Show(this,detail,"启动失败");
        }
    }
    void StartOriginal(){AudioSettings.Prepare(root,Path.Combine(root,"work","original-runtime","exec"));using(var game=OriginalRuntime.Start(root)){OriginalRuntime.Activate(game);}status.Text="原版模式";}
    bool GameRunning(){try{return aiGame!=null && !aiGame.HasExited;}catch{return false;}}
    void ReleaseSession(){if(host!=null){host.Dispose();host=null;}if(aiGame!=null){aiGame.Dispose();aiGame=null;}}
    protected override void Dispose(bool disposing){if(disposing){notice.Visible=false;notice.Dispose();monitor.Dispose();ReleaseSession();}base.Dispose(disposing);}
    [STAThread] static void Main(string[] args){
        if(args.Length<2)return;
        bool created;
        using(var mutex=new System.Threading.Mutex(true,"Local\\ReiOriginalAICompanion",out created)){
            if(!created){
                try{using(var signal=System.Threading.EventWaitHandle.OpenExisting("Local\\ReiOriginalAIShow"))signal.Set();}
                catch{MessageBox.Show("旧版 AI 窗口仍在运行，请关闭它后重新打开启动器；原版游戏可保持运行。");}
                return;
            }
            Application.EnableVisualStyles();var app=new Launcher(args[0],args[1]);
            using(var signal=new System.Threading.EventWaitHandle(false,System.Threading.EventResetMode.AutoReset,"Local\\ReiOriginalAIShow"))
            using(var timer=new Timer {Interval=250}){
                timer.Tick+=(s,e)=>{if(!signal.WaitOne(0))return;foreach(Form form in Application.OpenForms){if(form.Modal){form.Activate();return;}}app.WindowState=FormWindowState.Normal;app.Show();app.Activate();};
                timer.Start();Application.Run(app);
            }
        }
    }
}
