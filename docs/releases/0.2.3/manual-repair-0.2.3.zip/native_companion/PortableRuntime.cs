using System;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;

// Start only the already hash-verified bundled runtime. Disk executables, the
// registry, saves and resource archives are never modified. Apply before the
// primary thread runs, so neither original installation nor registration UI runs.
static class PortableRuntime {
    [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)]
    struct StartupInfo {
        public int cb; public string reserved, desktop, title;
        public int x,y,width,height,xChars,yChars,fill,flags;
        public short show, reservedSize; public IntPtr reservedData,input,output,error;
    }
    [StructLayout(LayoutKind.Sequential)]
    struct ProcessInfo { public IntPtr process,thread; public int pid,tid; }
    [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)]
    static extern bool CreateProcessW(string app,StringBuilder command,IntPtr pa,IntPtr ta,bool inherit,uint flags,IntPtr env,string cwd,ref StartupInfo startup,out ProcessInfo process);
    [DllImport("kernel32.dll",SetLastError=true)] static extern bool ReadProcessMemory(IntPtr p,IntPtr address,byte[] data,UIntPtr size,out UIntPtr count);
    [DllImport("kernel32.dll",SetLastError=true)] static extern bool WriteProcessMemory(IntPtr p,IntPtr address,byte[] data,UIntPtr size,out UIntPtr count);
    [DllImport("kernel32.dll",SetLastError=true)] static extern bool VirtualProtectEx(IntPtr p,IntPtr address,UIntPtr size,uint protection,out uint old);
    [DllImport("kernel32.dll",SetLastError=true)] static extern bool FlushInstructionCache(IntPtr p,IntPtr address,UIntPtr size);
    [DllImport("kernel32.dll",SetLastError=true)] static extern uint ResumeThread(IntPtr thread);
    [DllImport("kernel32.dll")] static extern bool TerminateProcess(IntPtr p,uint code);
    [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr handle);
    static void Require(bool ok) { if(!ok)throw new Win32Exception(Marshal.GetLastWin32Error(),"免安装启动失败，请保留完整游戏目录后重试。"); }
    internal static Process Start(string executable) {
        executable=Path.GetFullPath(executable);
        var start=new StartupInfo();start.cb=Marshal.SizeOf(start);
        ProcessInfo child;
        Require(CreateProcessW(executable,new StringBuilder("\""+executable+"\""),IntPtr.Zero,IntPtr.Zero,false,4,IntPtr.Zero,Path.GetDirectoryName(executable),ref start,out child));
        Process result=null; bool resumed=false;
        try {
            // Fixed-base x86 image: the full-file SHA is checked by each caller.
            // Verify mapped instructions as well; fail closed on relocation or drift.
            byte[] expected={0x8b,0x3d,0x0c,0x80,0x46,0x00,0x68,0xd8,0x2a,0x48,0x00,0x68,0x19,0x00,0x02};
            byte[] actual=new byte[expected.Length]; UIntPtr count;
            IntPtr address=new IntPtr(0x448dce);UIntPtr size=new UIntPtr((uint)actual.Length);
            Require(ReadProcessMemory(child.process,address,actual,size,out count) && count.ToUInt64()==(ulong)actual.Length);
            for(int i=0;i<expected.Length;i++)if(expected[i]!=actual[i])throw new InvalidOperationException("游戏启动代码不匹配，已停止启动。");
            // mov [registration_ready],1; jmp 00448ef5 (original window creation).
            byte[] patch={0xc7,0x05,0x78,0x2b,0x48,0x00,0x01,0x00,0x00,0x00,0xe9,0x18,0x01,0x00,0x00};
            uint old,ignored;Require(VirtualProtectEx(child.process,address,size,0x40,out old));
            Require(WriteProcessMemory(child.process,address,patch,size,out count) && count.ToUInt64()==(ulong)patch.Length);
            Require(VirtualProtectEx(child.process,address,size,old,out ignored));
            Require(FlushInstructionCache(child.process,address,size));
            result=Process.GetProcessById(child.pid);
            Require(ResumeThread(child.thread)!=UInt32.MaxValue);resumed=true;
            return result;
        } finally {
            if(!resumed){TerminateProcess(child.process,1);if(result!=null)result.Dispose();}
            CloseHandle(child.thread);CloseHandle(child.process);
        }
    }
}
