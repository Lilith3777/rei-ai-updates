using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Web.Script.Serialization;

public class ServiceConfig {
    public static bool IsLocalEndpoint(string value){
        Uri uri; System.Net.IPAddress address;
        return Uri.TryCreate(value,UriKind.Absolute,out uri) &&
            (uri.Scheme=="http" || uri.Scheme=="https") &&
            (uri.Host=="localhost" || uri.Host=="127.0.0.1" || (System.Net.IPAddress.TryParse(uri.DnsSafeHost,out address) && address.Equals(System.Net.IPAddress.IPv6Loopback))) &&
            uri.UserInfo=="" && uri.Query=="" && uri.Fragment=="" && uri.Port!=0;
    }
    public static bool IsValidEndpoint(string value){
        Uri uri;
        return Uri.TryCreate(value,UriKind.Absolute,out uri) && uri.Host!="" &&
            uri.UserInfo=="" && uri.Query=="" && uri.Fragment=="" && uri.Port!=0 &&
            (uri.Scheme=="https" || IsLocalEndpoint(value));
    }
    public bool CanConnect(){return enabled && IsValidEndpoint(base_url) &&
        !String.IsNullOrWhiteSpace(model) &&
        (!String.IsNullOrWhiteSpace(api_key) || IsLocalEndpoint(base_url));}
    public bool enabled {get;set;}
    public string base_url {get;set;}
    public string model {get;set;}
    public string api_key {get;set;}
    public ServiceConfig(){base_url="https://api.deepseek.com";model="deepseek-flash";api_key="";}
}

class ServiceConfigStore {
    public static ServiceConfig Load(string path){
        if(!File.Exists(path))return new ServiceConfig();
        byte[] clear=ProtectedData.Unprotect(File.ReadAllBytes(path),null,DataProtectionScope.CurrentUser);
        var config=new JavaScriptSerializer().Deserialize<ServiceConfig>(Encoding.UTF8.GetString(clear));
        if(config==null || config.base_url==null || config.model==null || config.api_key==null)
            throw new InvalidDataException("Invalid service configuration.");
        return config;
    }
    public static void Save(string path,ServiceConfig config){
        byte[] encrypted=ProtectedData.Protect(Encoding.UTF8.GetBytes(new JavaScriptSerializer().Serialize(config)),null,DataProtectionScope.CurrentUser);
        Directory.CreateDirectory(Path.GetDirectoryName(path));
        string temporary=path+"."+Guid.NewGuid().ToString("N")+".tmp";
        try{
            File.WriteAllBytes(temporary,encrypted);
            if(File.Exists(path))File.Replace(temporary,path,null);else File.Move(temporary,path);
        }finally{if(File.Exists(temporary))File.Delete(temporary);}
    }
}
