using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;

static class OriginalRuntime {
    internal static bool IsProcessRunning(int processId){
        try{using(var process=Process.GetProcessById(processId))return !process.HasExited;}
        catch(ArgumentException){return false;} // PID already disappeared.
    }
    internal static bool IsReusableProcess(Process process,string executable,string compatible){
        try{
            if(process.HasExited)return false;
            string path=process.MainModule.FileName;
            bool matches=String.Equals(path,executable,StringComparison.OrdinalIgnoreCase)||String.Equals(path,compatible,StringComparison.OrdinalIgnoreCase);
            // An exit can race path inspection; never activate an exited record.
            return matches && !process.HasExited;
        }catch{return false;}
    }
    [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr window,int command);
    [DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr window);
    [DllImport("user32.dll")] static extern bool IsIconic(IntPtr window);
    [DllImport("kernel32.dll",CharSet=CharSet.Unicode,ExactSpelling=true)] static extern IntPtr LoadLibraryExW(string file,IntPtr reserved,uint flags);
    [DllImport("kernel32.dll")] static extern bool FreeLibrary(IntPtr module);
    [DllImport("user32.dll",CharSet=CharSet.Unicode,ExactSpelling=true)] static extern int LoadStringW(IntPtr module,uint id,StringBuilder text,int capacity);
    [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr window,out uint process);
    [DllImport("user32.dll",CharSet=CharSet.Unicode,ExactSpelling=true)] static extern bool SetWindowTextW(IntPtr window,string text);
    public static Process Start(string root){
        foreach(string name in new[]{"eva-inset","eva-load-boundary","eva-bounded-wait","eva-timed-wait","eva-entry-gate","eva-entry-scoped","eva-scoped-load-boundary"})
            foreach(var candidate in Process.GetProcessesByName(name))
                using(candidate){if(!candidate.HasExited)throw new InvalidOperationException("请先正常退出正在运行的 AI 或测试版游戏，再启动原版。");}
        string folder=Path.Combine(root,"work","original-runtime","exec"),exe=Path.Combine(folder,"eva.exe");
        if(!File.Exists(exe)||!File.Exists(exe+".manifest"))throw new InvalidOperationException("原版副本或兼容清单缺失。");
        using(var hash=SHA256.Create())using(var file=File.OpenRead(exe)){
            if(BitConverter.ToString(hash.ComputeHash(file)).Replace("-","")!="6AE0057995EBF9F3FFA2B9320BE9C71CB1F574FC1B5B64016AADB6E7B15C5708")
                throw new InvalidOperationException("原版程序校验不匹配。");
        }
        string compatible=Path.Combine(folder,"eva-input-compat.exe");
        if(!File.Exists(compatible)||!File.Exists(compatible+".manifest"))throw new InvalidOperationException("中文输入兼容程序缺失，请修复安装。");
        using(var hash=SHA256.Create())using(var file=File.OpenRead(compatible)){
            if(BitConverter.ToString(hash.ComputeHash(file)).Replace("-","")!="A908E1CBD66CFE5538FC2932FA4F464DC86C8E0A6BC7DBBF9F49878DE90B2D20")
                throw new InvalidOperationException("中文输入兼容程序校验不匹配。");
        }
        var running=new List<Process>();
        var candidates=new List<Process>(Process.GetProcessesByName("eva"));candidates.AddRange(Process.GetProcessesByName("eva-input-compat"));
        foreach(var candidate in candidates){
            bool matches=IsReusableProcess(candidate,exe,compatible);
            if(matches)running.Add(candidate);else candidate.Dispose();
        }
        if(running.Count>1){foreach(var candidate in running)candidate.Dispose();throw new InvalidOperationException("检测到多个原版窗口，请关闭多余窗口后再启动。");}
        return running.Count==1?running[0]:PortableRuntime.Start(compatible);
    }
    public static void Activate(Process game){
        // The original path may return before CreateWindowEx has run. The AI
        // path already waits, but both paths need a real window before restore.
        game.Refresh();
        if(!game.HasExited && game.MainWindowHandle==IntPtr.Zero)game.WaitForInputIdle(10000);
        game.Refresh();IntPtr window=game.MainWindowHandle;
        if(window==IntPtr.Zero)return;
        RestoreOriginalCaption(game,window);
        if(IsIconic(window))ShowWindow(window,9);
        SetForegroundWindow(window);
    }
    static void RestoreOriginalCaption(Process game,IntPtr window){
        // Resource 103 is the original title, not a replacement UI asset. Load
        // the PE as data only; never execute its entry point in the launcher.
        IntPtr module=IntPtr.Zero;
        try{
            uint owner;GetWindowThreadProcessId(window,out owner);
            if(owner!=(uint)game.Id)return;
            module=LoadLibraryExW(game.MainModule.FileName,IntPtr.Zero,0x40);
            if(module==IntPtr.Zero)return;
            var title=new StringBuilder(256);
            if(LoadStringW(module,103,title,title.Capacity)<=0)return;
            // This is another process's top-level caption, not a child control.
            // Direct WM_SETTEXT goes through the original ANSI window procedure
            // and was observed truncating the Unicode title to two characters.
            SetWindowTextW(window,title.ToString());
        }catch{
            // A title update must never stop otherwise playable original game.
        }finally{if(module!=IntPtr.Zero)FreeLibrary(module);}
    }
}
