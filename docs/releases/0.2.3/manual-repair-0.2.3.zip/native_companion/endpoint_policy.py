"""Local AI is explicitly loopback-only; internet services still require TLS."""
from urllib.parse import urlsplit
import ipaddress

def local_host(host):
    if host in ("localhost", "127.0.0.1"):
        return True
    try:
        return ipaddress.ip_address(host) == ipaddress.IPv6Address("::1")
    except ValueError:
        return False



def local_endpoint(value):
    try:
        url = urlsplit(value)
        return (url.scheme in ('http', 'https') and
                local_host(url.hostname) and
                url.username is None and url.password is None and
                not url.query and not url.fragment and url.port != 0)
    except (ValueError, TypeError):
        return False


def valid_endpoint(value):
    try:
        url = urlsplit(value)
        return (bool(url.hostname) and url.username is None and url.password is None and
                not url.query and not url.fragment and url.port != 0 and
                (url.scheme == 'https' or local_endpoint(value)))
    except (ValueError, TypeError):
        return False
