﻿param([string]$PythonPath = '', [switch]$BuildOnly)
$ErrorActionPreference = 'Stop'
$projectPath = Split-Path $PSScriptRoot -Parent
if (-not $PythonPath) { $PythonPath = Join-Path $projectPath 'runtime\python\python.exe' }
function Test-ReiProcessRunning([int]$ProcessId) {
    try {
        $gameProcess = [Diagnostics.Process]::GetProcessById($ProcessId)
        try { return -not $gameProcess.HasExited }
        finally { $gameProcess.Dispose() }
    } catch [ArgumentException] { return $false }
}
$backupPath = Join-Path $projectPath 'patch-backups'
if (Test-Path -LiteralPath $backupPath) {
    $pendingPatch = @(Get-ChildItem -LiteralPath $backupPath -Filter 'transaction.json' -Recurse | Where-Object {
        (Get-Content -LiteralPath $_.FullName -Raw | ConvertFrom-Json).state -eq 'prepared'
    })
    if ($pendingPatch.Count -gt 0) {
        $runningGame = @(Get-CimInstance Win32_Process | Where-Object {
            ($_.Name -eq 'eva.exe' -or $_.Name -like 'eva-*' -or
            ($_.Name -in @('python.exe','pythonw.exe') -and $_.CommandLine -like '*native_exchange_host.py*')) -and
            (Test-ReiProcessRunning -ProcessId $_.ProcessId)
        })
        if ($runningGame.Count -gt 0) { throw '请先退出游戏及 AI 后台，再重新打开启动器以恢复未完成的更新。' }
        & $PythonPath -B (Join-Path $backupPath 'recovery_engine.py') --recover $projectPath
        if ($LASTEXITCODE -ne 0) { throw '未完成的更新无法恢复，备份已保留，请联系作者。' }
    }
}
$csharpCompiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\csc.exe'
function Build-GameComponent([string]$Name, [string[]]$Sources, [string]$Entry = '') {
    $componentPath = Join-Path $projectPath ('work\'+$Name+'.exe')
    $componentSources = @($Sources | ForEach-Object { Join-Path $projectPath $_ })
    $stampPath = $componentPath+'.build.json'
    # Patch archives can preserve old timestamps. Check source and output
    # contents, not modification dates, before reusing a native helper.
    $identity = @('native-component-v1', $Entry, '/platform:x86', '/r:System.Web.Extensions.dll')
    $identity += @($componentSources | ForEach-Object { (Get-FileHash -LiteralPath $_ -Algorithm SHA256).Hash })
    $identity += (Get-FileHash -LiteralPath $csharpCompiler -Algorithm SHA256).Hash
    $buildHasher = [Security.Cryptography.SHA256]::Create()
    try { $inputHash = ([BitConverter]::ToString($buildHasher.ComputeHash([Text.Encoding]::UTF8.GetBytes(($identity -join '|'))))).Replace('-','') }
    finally { $buildHasher.Dispose() }
    $needsBuild = $true
    if ((Test-Path -LiteralPath $componentPath) -and (Test-Path -LiteralPath $stampPath)) {
        try {
            $stamp = Get-Content -LiteralPath $stampPath -Raw | ConvertFrom-Json
            $needsBuild = $stamp.inputHash -ne $inputHash -or $stamp.outputHash -ne (Get-FileHash -LiteralPath $componentPath -Algorithm SHA256).Hash
        } catch { $needsBuild = $true }
    }
    if ($needsBuild) {
        $temporaryComponent = Join-Path (Split-Path $componentPath -Parent) ('build-'+[Guid]::NewGuid().ToString('N')+'.exe')
        try {
            $compilerOptions = @('/nologo','/platform:x86','/r:System.Web.Extensions.dll',('/out:'+$temporaryComponent))
            if ($Entry) { $compilerOptions += ('/main:'+$Entry) }
            & $csharpCompiler @compilerOptions @componentSources
            if ($LASTEXITCODE -ne 0) { throw '游戏组件更新失败，请退出游戏后重试。' }
            $outputHash = (Get-FileHash -LiteralPath $temporaryComponent -Algorithm SHA256).Hash
            Move-Item -LiteralPath $temporaryComponent -Destination $componentPath -Force
            @{ inputHash=$inputHash; outputHash=$outputHash } | ConvertTo-Json | Set-Content -LiteralPath $stampPath -Encoding UTF8
        } finally {
            if (Test-Path -LiteralPath $temporaryComponent) { Remove-Item -LiteralPath $temporaryComponent }
        }
    }
}
Build-GameComponent 'NativeSaveObserverProbe' @('tools\compatibility\NativeSaveObserverProbe.cs','native_companion\NativeGameContext.cs','tools\compatibility\NativeDialogueCapture.cs')
Build-GameComponent 'NativeReplyChannel' @('tools\compatibility\NativeReplyChannel.cs')
Build-GameComponent 'NativeLoadMonitor' @('tools\compatibility\NativeNumericStateProbe.cs','tools\compatibility\NativeLoadMonitor.cs') 'NativeLoadMonitor'
Build-GameComponent 'NativeSceneFoodPublisher' @('tools\compatibility\NativeSceneFoodPublisher.cs')
$buildPath = Join-Path $projectPath 'work\native-companion'
New-Item -ItemType Directory -Path $buildPath -Force | Out-Null
$sourcePaths = @('Launcher.cs','AudioSettings.cs','AudioSettingsDialog.cs','AudioDriverPayload.cs','UpdateDialog.cs','ContactDialog.cs','OriginalRuntime.cs','PortableRuntime.cs','InsetRuntime.cs','NativeExchangeHostClient.cs','ServiceConfig.cs','ServiceSettingsDialog.cs','ServiceConnectionCheck.cs','RequestTransport.cs') | ForEach-Object { Join-Path $projectPath ('native_companion\'+$_) }
$contactAsset = Join-Path $projectPath 'native_companion\assets\author-contact.png'
$sourceHashes = ($sourcePaths | ForEach-Object { (Get-FileHash -LiteralPath $_ -Algorithm SHA256).Hash }) -join ''
$sourceHashes += (Get-FileHash -LiteralPath $contactAsset -Algorithm SHA256).Hash
$sourceHashes += (Get-FileHash -LiteralPath $csharpCompiler -Algorithm SHA256).Hash
$sourceHashes += 'launcher-v2|winexe|x86|Security|Management|Windows.Forms|Drawing|Web.Extensions|Rei.AuthorContact'
$hasher = [System.Security.Cryptography.SHA256]::Create()
try { $buildId = ([BitConverter]::ToString($hasher.ComputeHash([Text.Encoding]::UTF8.GetBytes($sourceHashes)))).Replace('-','').Substring(0,20) } finally { $hasher.Dispose() }
$application = Join-Path $buildPath ('Companion-'+$buildId+'.exe')
$applicationStamp = $application+'.build.json'
$needsLauncherBuild = $true
if ((Test-Path -LiteralPath $application) -and (Test-Path -LiteralPath $applicationStamp)) {
    try {
        $stamp = Get-Content -LiteralPath $applicationStamp -Raw | ConvertFrom-Json
        $needsLauncherBuild = $stamp.inputHash -ne $buildId -or $stamp.outputHash -ne (Get-FileHash -LiteralPath $application -Algorithm SHA256).Hash
    } catch { $needsLauncherBuild = $true }
}
if ($needsLauncherBuild) {
    $temporaryBuild = Join-Path $buildPath ('build-'+[Guid]::NewGuid().ToString('N')+'.exe')
    $temporaryStamp = $temporaryBuild+'.build.json'
    try {
        & $csharpCompiler /nologo /target:winexe /platform:x86 /r:System.Security.dll /r:System.Management.dll /r:System.Windows.Forms.dll /r:System.Drawing.dll /r:System.Web.Extensions.dll "/resource:$contactAsset,Rei.AuthorContact" "/out:$temporaryBuild" @sourcePaths
        if ($LASTEXITCODE -ne 0) { throw 'AI窗口编译失败。' }
        $outputHash = (Get-FileHash -LiteralPath $temporaryBuild -Algorithm SHA256).Hash
        @{ inputHash=$buildId; outputHash=$outputHash } | ConvertTo-Json | Set-Content -LiteralPath $temporaryStamp -Encoding UTF8
        Move-Item -LiteralPath $temporaryBuild -Destination $application -Force
        Move-Item -LiteralPath $temporaryStamp -Destination $applicationStamp -Force
    } finally {
        if (Test-Path -LiteralPath $temporaryBuild) { Remove-Item -LiteralPath $temporaryBuild }
        if (Test-Path -LiteralPath $temporaryStamp) { Remove-Item -LiteralPath $temporaryStamp }
    }
}
if ($BuildOnly) { Write-Output $application; return }
Start-Process -FilePath $application -ArgumentList @(('"'+$projectPath+'"'), ('"'+$PythonPath+'"')) -WorkingDirectory $projectPath
