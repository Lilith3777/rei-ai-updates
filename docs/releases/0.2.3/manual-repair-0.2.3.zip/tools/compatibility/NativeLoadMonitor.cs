using System;

using System.IO;

using System.Text;

using System.Threading;

using System.Diagnostics;

using System.Collections.Generic;

using System.Runtime.InteropServices;

using System.Security.Cryptography;

using System.Web.Script.Serialization;



// Owns only the private bounded load gate. Never writes original variables.

partial class NativeNumericStateProbe {

    [DllImport("kernel32.dll")] static extern bool WriteProcessMemory(IntPtr h,IntPtr p,byte[] b,UIntPtr n,out UIntPtr got);

    volatile bool monitorClosed;

    void LoadWrite(int offset,uint value){

        if(offset!=0&&offset!=12)throw new Exception("Invalid private write");

        if(Encoding.ASCII.GetString(Read(VA(0x5a2018),8))!="REILDG01")throw new Exception("Gate mismatch");

        UIntPtr count;var bytes=BitConverter.GetBytes(value);

        if(!WriteProcessMemory(handle,new IntPtr(VA(0x5a2000)+offset),bytes,(UIntPtr)4,out count)||count.ToUInt64()!=4)throw new Exception("Gate write failed");

    }

    static FileStream LoadResource(string path,string expected){

        var file=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.ReadWrite);

        try{using(var sha=SHA256.Create())if(BitConverter.ToString(sha.ComputeHash(file)).Replace("-","")!=expected)throw new Exception("Profile mismatch");file.Dispose();return null;}catch{file.Dispose();throw;}

    }

    void EmitLoad(object value){Console.WriteLine(new JavaScriptSerializer {MaxJsonLength=4194304}.Serialize(value));Console.Out.Flush();}

    void MonitorLoads(Process game){

        imageBase=game.MainModule.BaseAddress.ToInt64();handle=OpenProcess(0x1038,false,game.Id);

        if(handle==IntPtr.Zero)throw new Exception("Load observer access failed");

        var control=new Thread(()=>{try{while(Console.ReadLine()!=null){break;}}finally{monitorClosed=true;}}){IsBackground=true};control.Start();

        long gate=VA(0x5a2000),events=VA(0x496000),capture=VA(0x498000);uint waiting=0;

        try{

            if(U(gate)!=0||U(gate+8)!=0)throw new Exception("Gate already owned");

            LoadWrite(0,1);EmitLoad(new {ready=true});

            while(!monitorClosed&&!game.HasExited){

                timer.Restart();waiting=U(gate+8);

                if(waiting==0){if(U(gate)==0)LoadWrite(0,1);Thread.Sleep(5);continue;}

                uint version=U(events+8),sequence=U(events+12),length=U(capture+16);

                int slot=I(VA(0x47a250))+1;

                if((version&1)==0||sequence==uint.MaxValue||slot<1||slot>18||U(gate+4)!=waiting||U(gate+16)!=0||

                   Encoding.ASCII.GetString(Read(capture,8))!="REICAP01"||U(capture+20)!=0||length==0||length>1048576)throw new Exception("Invalid load boundary");

                var raw=Read(capture+32,(int)length);

                numericNames.Clear();stringNames.Clear();var first=Values();var second=Values();var json=new JavaScriptSerializer {MaxJsonLength=4194304};

                if(json.Serialize(first)!=json.Serialize(second)||U(gate+8)!=waiting||U(gate+16)!=0||U(events+8)!=version||U(events+12)!=sequence||U(capture+16)!=length||U(capture+20)!=0)throw new Exception("Load changed during capture");

                LoadWrite(12,waiting);var deadline=Stopwatch.StartNew();

                while(U(events+8)!=version+1||U(events+12)!=sequence+1){if(deadline.ElapsedMilliseconds>1500||monitorClosed)throw new Exception("Load did not complete");Thread.Sleep(1);}

                long record=events+24+(sequence%128)*16;

                if(U(gate+16)!=1||U(gate+8)!=0||U(record)!=sequence+1||U(record+4)!=2||I(record+8)!=slot||I(record+12)!=0||U(capture+8)!=0||U(capture+28)!=sequence+1||U(events+8)!=version+1)throw new Exception("Load completion changed");

                string hash;using(var sha=SHA256.Create())hash=BitConverter.ToString(sha.ComputeHash(raw)).Replace("-","").ToLowerInvariant();

                EmitLoad(new {process_id=game.Id,started_utc=game.StartTime.ToUniversalTime().ToString("o"),save_sequence=sequence+1,slot=slot,

                    boundary_captured=true,stream_sha256=hash,stream_length=raw.Length,stream_base64=Convert.ToBase64String(raw),numeric_state=first});

                waiting=0;LoadWrite(0,1);

            }

        }finally{try{timer.Restart();LoadWrite(0,0);uint pending=U(gate+8);if(pending!=0)LoadWrite(12,pending);}catch{}CloseHandle(handle);}

    }

    public static int MonitorMain(string[] args){
        Console.OutputEncoding = new UTF8Encoding(false, true);
        try{

        if(args.Length!=2)throw new Exception("Expected PID and project");

        string path=Path.GetFullPath(Path.Combine(args[1],"work/in-game-scoped-load-boundary-prototype/runtime/exec/eva-scoped-load-boundary.exe"));

        string folder=Path.GetDirectoryName(Path.GetDirectoryName(path));

        using(var game=Process.GetProcessById(int.Parse(args[0])))

        using(var file=LoadResource(path,"67F57C9C5E768169254D14A5E68D5C7DFA954E325FBD6F0C6AE0E6B4EDBC5188"))

        using(var index=LoadResource(Path.Combine(folder,"exec.idx"),"69C586E8EC27E14F1EC7268B36D9154D8F34C899D124694891685D05137043EE"))

        using(var archive=LoadResource(Path.Combine(folder,"exec.lb5"),"5940E6D849F358BCBC59A906534AB63603B5BEB014F20D59534CE5BE1254BFCC")){

            if(!String.Equals(game.MainModule.FileName,path,StringComparison.OrdinalIgnoreCase))throw new Exception("Wrong game path");

            new NativeNumericStateProbe {inferTypes=true,numericNames=new HashSet<string>()}.MonitorLoads(game);

        }return 0;

    }catch{Console.Error.WriteLine("Load memory observer unavailable.");return 1;}}

}

class NativeLoadMonitor {static int Main(string[] args){return NativeNumericStateProbe.MonitorMain(args);}}

