using System;

using System.IO;

using System.Diagnostics;

using System.Collections.Generic;

using System.Runtime.InteropServices;

using System.Security.Cryptography;

using System.Text;

using System.Web.Script.Serialization;



// Read-only candidate diagnostic, not a production completion detector.

class NativeSaveObserverProbe {

    class ObservationBusy : Exception { public ObservationBusy(string message):base(message){} }

    [DllImport("kernel32.dll")] static extern IntPtr OpenProcess(uint rights,bool inherit,int pid);

    [DllImport("kernel32.dll")] static extern bool ReadProcessMemory(IntPtr process,IntPtr address,byte[] bytes,UIntPtr size,out UIntPtr count);

    [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr process);

    static byte[] Read(IntPtr handle,long address,int size){

        byte[] data=new byte[size];UIntPtr count;

        if(!ReadProcessMemory(handle,new IntPtr(address),data,(UIntPtr)size,out count)||count.ToUInt64()!=(ulong)size)throw new Exception("Incomplete read");

        return data;

    }

    static uint U(IntPtr handle,long address){return BitConverter.ToUInt32(Read(handle,address,4),0);}

    static uint PhasePointer(IntPtr handle,long address){

        uint value=U(handle,address);

        if(value==0)throw new ObservationBusy("Game phase is not initialized");

        return value;

    }

    static string Ascii(IntPtr handle,long address){

        var bytes=new List<byte>();

        for(int n=0;n<260;n++){

            byte value=Read(handle,address+n,1)[0];

            if(value==0)return Encoding.ASCII.GetString(bytes.ToArray());

            bytes.Add(value);

        }

        throw new Exception("Unterminated phase metadata");

    }

    static Dictionary<string,object> Phase(IntPtr handle,long imageBase){

        long parser=imageBase+0x82988;

        string script=Path.GetFileName(Ascii(handle,PhasePointer(handle,parser+0x40))).ToLowerInvariant();

        string command=Ascii(handle,PhasePointer(handle,PhasePointer(handle,PhasePointer(handle,PhasePointer(handle,parser+0x4c)+8))+4));

        int title=BitConverter.ToInt32(Read(handle,imageBase+0x7b2b8,4),0);

        int position=BitConverter.ToInt32(Read(handle,parser+0x94,4),0);

        if((title!=0&&title!=1)||position<0||

           !System.Text.RegularExpressions.Regex.IsMatch(script,@"^[a-z0-9_]+\.txt$")||

           !System.Text.RegularExpressions.Regex.IsMatch(command,@"^[a-zA-Z0-9_.]+$"))throw new ObservationBusy(

               "Invalid phase metadata during transition: title="+title+", script="+script+", command="+command+", position="+position);

        return new Dictionary<string,object>{{"title_active",title},{"script",script},{"command",command},{"position",position}};

    }

    static FileStream VerifyResource(string path,string expected){

        var file=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.ReadWrite);

        try{

            using(var sha=SHA256.Create())

                if(BitConverter.ToString(sha.ComputeHash(file)).Replace("-","")!=expected)

                    throw new Exception("Unexpected exchange resource");

            file.Dispose();return null;

        }catch{file.Dispose();throw;}

    }

    static int Main(string[] args){
        Console.OutputEncoding = new UTF8Encoding(false, true);

        try{

            if(args.Length!=2 || args[1]!="--shop-observer")throw new Exception("Explicit buffered profile required");
            bool playable=true;

            bool scoped=playable || args.Length==2 && args[1]=="--entry-scoped-observer";

            bool timed=args.Length==2 && args[1]=="--timed-observer";

            bool inset=scoped || timed || args.Length==2 && args[1]=="--inset-observer";

            bool multiline=args.Length==2 && args[1]=="--multiline-observer";

            bool exchange=inset || multiline || args.Length==2 && args[1]=="--exchange-observer";

            bool io=exchange || (args.Length==2 && args[1]=="--io-observer");

            bool loop=io || (args.Length==2 && args[1]=="--loop-observer");

            if(args.Length!=1 && !loop)throw new Exception("Expected PID and optional explicit observer profile");

            using(var game=Process.GetProcessById(int.Parse(args[0]))){

                string fingerprint;

                using(var sha=SHA256.Create())using(var stream=File.OpenRead(game.MainModule.FileName))

                    fingerprint=BitConverter.ToString(sha.ComputeHash(stream)).Replace("-","");

                bool operationGuarded=fingerprint==(playable?"67F57C9C5E768169254D14A5E68D5C7DFA954E325FBD6F0C6AE0E6B4EDBC5188":scoped?"222CC1778D96CF39DBEF665D8032B3C27F9347A3BFB1C2FB1F9EDD907D8930CD":timed?"7C81F2A3969F956ED9F6D75F06F8BF5FB9D60699B2B63C8A4DE0EE29085B8B12":inset?"96890012A22044831434F87FC2663730606454EBEB4C858E252AFEB6DFCB4849":multiline?"EFFD76AEC626B338BB0C19A57AAC119A0DC0DE06D300E8429AA4EE20036C6B42":exchange?

                    "7D8FF805A76550B5E600588545D0D942B6F7A3CBB1652BB494FC86A76CCC69D9":io?

                    "2997FDDCFABE7B1FC7DE89FB678535E6331DC7BA65CD252CBCB5F7F2799C06A7":loop?

                    "B473EBA2C12C155689BACB5879265E48C086DD71045A429BFE7B2933690F173A":

                    "E2645DE19B9C10E801AB9B0E8290C4125091B16642DDCDB2B3922B1FE73BDC96");

                if(!operationGuarded&&(loop||fingerprint!="8247E16F331A0D54DECE9D2850AB2E79BEBEB8756F351D1FB1A79DC9004E8A7F"))throw new Exception("Not the observer candidate");

                string runtime=Path.GetDirectoryName(Path.GetDirectoryName(game.MainModule.FileName));

                if(exchange && !String.Equals(Path.GetFileName(game.MainModule.FileName),playable?"eva-scoped-load-boundary.exe":scoped?"eva-entry-scoped.exe":timed?"eva-timed-wait.exe":inset?"eva-inset.exe":multiline?"eva-multiline.exe":"eva-exchange.exe",StringComparison.OrdinalIgnoreCase))

                    throw new Exception("Unexpected exchange executable name");

                using(var resourceIndex=exchange && !playable?VerifyResource(Path.Combine(runtime,"exec.idx"),scoped?"6B4A93FC4AC5802C75FA77FF130197B18095EF3427AE84F263042E5E8D975DF3":inset?"218723CB25CA0A9AD10D7FE99EFFDC340D82A8185FBBA5359E56625DA9DFBDA4":"D333616189225B3F4498DA54589A48D47A1F0D5697ACF19FDAE25E998937E09F"):null)

                using(var archive=exchange && !playable?VerifyResource(Path.Combine(runtime,"exec.lb5"),scoped?"FF715B95B5DC9BC416D599DF9622700DCA6225847D4A9B53BFBECB8981D7BFF4":inset?"2B03A0ACE1A308C7E999C664B5B7CFD7B26A752A0E78C74CC7750C3827673837":"2B06EA78C422D7EAF4BC03389BDDC284451DD540B7B803F79BBAE7A44D066862"):null){

                IntPtr handle=OpenProcess(0x1010,false,game.Id);

                if(handle==IntPtr.Zero)throw new Exception("Read access unavailable");

                try{

                    long address=game.MainModule.BaseAddress.ToInt64()+(loop?0x96000:0x91000);

                    uint before=BitConverter.ToUInt32(Read(handle,address+8,4),0);

                    if((before&1)!=0)throw new ObservationBusy("Record publication in progress");

                    long dialogueAddress=game.MainModule.BaseAddress.ToInt64()+0x1a5000;
                    byte[] dialogueBefore=NativeDialogueCapture.Begin((a,n)=>Read(handle,a,n),dialogueAddress);
                    byte[] data=Read(handle,address,24+128*16);

                    object capture=null;

                    if(io){

                        long captureAddress=game.MainModule.BaseAddress.ToInt64()+0x98000;

                        byte[] header=Read(handle,captureAddress,32);

                        uint length=BitConverter.ToUInt32(header,16),error=BitConverter.ToUInt32(header,20);

                        if(Encoding.ASCII.GetString(header,0,8)!="REICAP01" ||

                           BitConverter.ToUInt32(header,24)!=1048576 || length>1048576)

                            throw new Exception("Capture schema mismatch");

                        if(BitConverter.ToUInt32(header,8)!=0)throw new ObservationBusy("Capture in progress");

                        uint observedSequence=BitConverter.ToUInt32(data,12),capturedSequence=BitConverter.ToUInt32(header,28);

                        bool captured=observedSequence!=0 && capturedSequence==observedSequence && error==0 && length>0;

                        string capturedHash=null;

                        if(captured)using(var sha=SHA256.Create())

                            capturedHash=BitConverter.ToString(sha.ComputeHash(Read(handle,captureAddress+32,(int)length))).Replace("-","");

                        capture=new {sequence=capturedSequence,length=length,error=error,captured=captured,

                            sha256=capturedHash,complete_file_verified=false,memory_binding_verified=false};

                    }

                    var serializer=new JavaScriptSerializer();

                    var phase=Phase(handle,game.MainModule.BaseAddress.ToInt64());

                    var context=operationGuarded?NativeGameContext.TryReadObserved(game,exchange,multiline,inset,timed,scoped,playable):null;

                    if(context!=null && (!Equals(context["script"],phase["script"]) ||

                        !Equals(context["command"],phase["command"]) || !Equals(context["position"],phase["position"])))context=null;

                    if(serializer.Serialize(phase)!=serializer.Serialize(Phase(handle,game.MainModule.BaseAddress.ToInt64())))throw new ObservationBusy("Game phase changed; retry");

                    byte[] dialogue=NativeDialogueCapture.Complete((a,n)=>Read(handle,a,n),dialogueAddress,dialogueBefore);
                    uint after=BitConverter.ToUInt32(Read(handle,address+8,4),0);

                    if(before!=after||BitConverter.ToUInt32(data,8)!=before)throw new ObservationBusy("Observation changed; retry");

                    if(Encoding.ASCII.GetString(data,0,8)!="REIEVT01"||BitConverter.ToInt32(data,16)!=128||BitConverter.ToInt32(data,20)!=16)throw new Exception("Observer schema mismatch");

                    uint sequence=BitConverter.ToUInt32(data,12);

                    var records=new List<object>();

                    uint retained=Math.Min(sequence,128u);

                    for(uint index=0;index<retained;index++){

                        uint seq=sequence-retained+index+1;

                        int at=24+(int)((seq-1)%128)*16;

                        if(BitConverter.ToUInt32(data,at)!=seq)throw new Exception("Incomplete retained history");

                        records.Add(new {sequence=seq,operation=BitConverter.ToInt32(data,at+4),

                            slot=BitConverter.ToInt32(data,at+8),native_return=BitConverter.ToInt32(data,at+12)});

                    }

                    Console.WriteLine(new JavaScriptSerializer().Serialize(new {

                        process_id=game.Id,process_started_utc=game.StartTime.ToUniversalTime().ToString("o"),

                        executable_path=game.MainModule.FileName,

                        sequence=sequence,records=records,access="read_only",file_validity_verified=false,

                        operation_guarded=operationGuarded,observer_fingerprint=fingerprint,phase=phase,game_context=context,

                        dialogue_guarded=true,dialogue_ring_base64=Convert.ToBase64String(dialogue),save_capture=capture,resource_profile=scoped?"native-entry-buffered-v6":inset?"native-inset-v1":exchange?"native-exchange-v1":null}));

                }finally{CloseHandle(handle);}

                }

            }

            return 0;

        }catch(NativeDialogueBusy error){Console.Error.WriteLine(error.Message);return 2;}
        catch(ObservationBusy error){Console.Error.WriteLine(error.Message);return 2;}

        catch(Exception error){Console.Error.WriteLine(error.Message);return 1;}

    }

}

