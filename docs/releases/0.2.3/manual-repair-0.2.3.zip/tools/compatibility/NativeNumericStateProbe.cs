using System;

using System.IO;

using System.Text;

using System.Diagnostics;

using System.Collections.Generic;

using System.Runtime.InteropServices;

using System.Security.Cryptography;

using System.Web.Script.Serialization;



// Explicit isolated-candidate diagnostic. ReadProcessMemory only; never applies state.

// Numeric names come from the locally decoded save. Kind describes array layout,

// not value type; unselected string fields must never be interpreted as numbers.

partial class NativeNumericStateProbe {

    [DllImport("kernel32.dll")] static extern IntPtr OpenProcess(uint rights,bool inherit,int pid);

    [DllImport("kernel32.dll")] static extern bool ReadProcessMemory(IntPtr h,IntPtr p,byte[] b,UIntPtr n,out UIntPtr got);

    [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr h);

    HashSet<string> numericNames; HashSet<string> stringNames=new HashSet<string>(); bool inferTypes; IntPtr handle; long imageBase; Stopwatch timer=Stopwatch.StartNew();
    byte[] Read(long p,int n){

        if(timer.ElapsedMilliseconds>5000 || p<65536 || p>0xffffffffL-n)throw new Exception("Invalid or timed out read");

        var b=new byte[n];UIntPtr got;

        if(!ReadProcessMemory(handle,new IntPtr(p),b,(UIntPtr)n,out got)||got.ToUInt64()!=(ulong)n)throw new Exception("Incomplete read");

        return b;

    }

    uint U(long p){return BitConverter.ToUInt32(Read(p,4),0);}

    int I(long p){return BitConverter.ToInt32(Read(p,4),0);}

    long VA(int p){return imageBase+p-0x400000;}

    string Name(long p){var b=new List<byte>();for(int i=0;i<64;i++){byte v=Read(p+i,1)[0];if(v==0)return Encoding.ASCII.GetString(b.ToArray());if(v>127)throw new Exception("Invalid name");b.Add(v);}throw new Exception("Long name");}

    // Array entries may point into script text: use their stored byte length.

    // Scalar buffers are capacity-bounded and require a NUL terminator.

    string StringHash(long pointer,int capacity,bool fixedLength=false){

        if(capacity<0||capacity>65536)throw new Exception("String capacity");

        byte[] bytes=fixedLength&&capacity==0?new byte[0]:Read(pointer,capacity+(fixedLength?0:1));int length=fixedLength?capacity:Array.IndexOf(bytes,(byte)0);

        if(length<0)throw new Exception("Unterminated saved string");

        using(var sha=SHA256.Create())return BitConverter.ToString(sha.ComputeHash(bytes,0,length)).Replace("-","").ToLowerInvariant();

    }

    Dictionary<string,object> Values(){

        long manager=VA(0x47ba08);int count=I(manager+0x20);

        if(count<1||count>2048)throw new Exception("Variable count");

        long node=U(manager);var seen=new HashSet<long>();var names=new HashSet<string>();

        var records=new List<Dictionary<string,object>>();int maximum=-1,stringMaximum=-1;

        for(int i=0;i<count;i++){

            if(!seen.Add(node))throw new Exception("Variable cycle");

            long value=U(node+8);string name=Name(U(U(value+0x20)+4));

            if(!names.Add(name))throw new Exception("Duplicate variable");

            int kind=I(value+4),size=kind==1?I(value+12):1,offset=kind==1?I(value+8):0;

            var r=new Dictionary<string,object>{{"name",name},{"kind",kind}};
            if(inferTypes){if(I(value+0x10)==0)numericNames.Add(name);else stringNames.Add(name);}
            if(numericNames.Contains(name)&&I(value+0x10)!=0)throw new Exception("Numeric type changed");

            if(stringNames.Contains(name)&&I(value+0x10)==0)throw new Exception("String type changed");

            if(stringNames.Contains(name)&&kind==0)r["string_hashes"]=new string[]{StringHash(U(value+0x18),I(value+0x1c))};

            if(numericNames.Contains(name)&&kind==0)r["values"]=new int[]{I(value)};

            if((numericNames.Contains(name)||stringNames.Contains(name))&&kind==1){

                if(size<1||size>16384||offset<0||offset>16384-size)throw new Exception("Array bounds");

                maximum=Math.Max(maximum,offset+size-1);

                if(stringNames.Contains(name)){stringMaximum=Math.Max(stringMaximum,offset+size-1);r["string_array"]=true;}

                r["size"]=size;r["offset"]=offset;

            }

            records.Add(r);node=U(node);

        }

        var pool=new List<int>();var poolSeen=new HashSet<long>();long item=U(VA(0x47b9d0));

        for(int i=0;i<=maximum;i++){

            if(!poolSeen.Add(item))throw new Exception("Pool cycle");

            pool.Add(I(U(item+8)));item=U(item);

        }

        var strings=new List<uint>();var stringSeen=new HashSet<long>();long stringItem=U(VA(0x47b9e4));

        for(int i=0;i<=stringMaximum;i++){

            if(!stringSeen.Add(stringItem))throw new Exception("String pool cycle");

            strings.Add(U(U(stringItem+8)));stringItem=U(stringItem);

        }

        foreach(var r in records)if(r.ContainsKey("offset")){

            int offset=(int)r["offset"],size=(int)r["size"];

            if(r.ContainsKey("string_array")){

                var hashes=new List<string>();

                for(int j=0;j<size;j++){try{hashes.Add(StringHash(strings[offset+j],pool[offset+j],true));}catch(Exception e){throw new Exception("String array "+r["name"]+" index "+j+" capacity "+pool[offset+j]+": "+e.Message);}}

                r["string_hashes"]=hashes.ToArray();r.Remove("string_array");

            }else r["values"]=pool.GetRange(offset,size).ToArray();

            r.Remove("offset");r.Remove("size");

        }

        return new Dictionary<string,object>{{"count",count},{"variables",records}};

    }

    object Run(Process game){

        imageBase=game.MainModule.BaseAddress.ToInt64();handle=OpenProcess(0x1010,false,game.Id);

        if(handle==IntPtr.Zero)throw new Exception("Read access unavailable");

        try{

            long events=VA(0x496000),parser=VA(0x482988);uint guard=U(events+8),seq=U(events+12);

            if((guard&1)!=0||I(VA(0x47b2b8))!=0||Encoding.ASCII.GetString(Read(events,8))!="REIEVT01")throw new Exception("Inactive or unstable game");

            string script=Name(U(parser+0x40));int position=I(parser+0x94);

            var serializer=new JavaScriptSerializer();var first=Values();var second=Values();

            if(serializer.Serialize(first)!=serializer.Serialize(second)||guard!=U(events+8)||seq!=U(events+12)||script!=Name(U(parser+0x40))||position!=I(parser+0x94)||I(VA(0x47b2b8))!=0)throw new Exception("State changed during capture");

            return new {process_id=game.Id,started_utc=game.StartTime.ToUniversalTime().ToString("o"),save_sequence=seq,script=script,position=position,access="read_only",numeric_state=first,load_verified=false};

        }finally{CloseHandle(handle);}

    }

    static int Main(string[] args){
        Console.OutputEncoding = new UTF8Encoding(false, true);
        try{

        if(args.Length!=3&&args.Length!=4)throw new Exception("Expected PID, project root, numeric-field list and optional string-field list");

        var strings=args.Length==4?new JavaScriptSerializer().Deserialize<string[]>(File.ReadAllText(args[3])):new string[0];

        if(strings==null||strings.Length>2048)throw new Exception("Invalid string field list");

        var names=new JavaScriptSerializer().Deserialize<string[]>(File.ReadAllText(args[2]));

        if(names==null||names.Length<1||names.Length>2048)throw new Exception("Invalid field list");

        using(var game=Process.GetProcessById(int.Parse(args[0]))){

            string expected=Path.GetFullPath(Path.Combine(args[1],"work/in-game-inset-prototype/runtime/exec/eva-inset.exe"));

            if(!String.Equals(expected,game.MainModule.FileName,StringComparison.OrdinalIgnoreCase))throw new Exception("Wrong isolated path");

            using(var file=new FileStream(expected,FileMode.Open,FileAccess.Read,FileShare.Read))using(var sha=SHA256.Create()){

                if(BitConverter.ToString(sha.ComputeHash(file)).Replace("-","")!="96890012A22044831434F87FC2663730606454EBEB4C858E252AFEB6DFCB4849")throw new Exception("Wrong candidate");

                Console.WriteLine(new JavaScriptSerializer().Serialize(new NativeNumericStateProbe{numericNames=new HashSet<string>(names),stringNames=new HashSet<string>(strings)}.Run(game)));

            }

        }return 0;

    }catch(Exception e){Console.Error.WriteLine(e.Message);return 1;}}

}

